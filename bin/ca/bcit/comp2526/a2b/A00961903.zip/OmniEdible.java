package ca.bcit.comp2526.a2b;

/**
 * Type can be eaten by Omnivore.
 * @author Kent, Huang
 *
 */
public interface OmniEdible {}
