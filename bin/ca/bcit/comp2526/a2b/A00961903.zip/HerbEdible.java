package ca.bcit.comp2526.a2b;

/**
 * Type can be eaten by Herbivore.
 * @author Kent, Huang
 *
 */
public interface HerbEdible{}
