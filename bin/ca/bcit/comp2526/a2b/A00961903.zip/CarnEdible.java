package ca.bcit.comp2526.a2b;

/**
 * Type can be eaten by Carnivore.
 * @author Kent, Huang
 *
 */
public interface CarnEdible {

}
